#include <string.h>
#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <fcntl.h>
#include "lib.h"

#define HOST "127.0.0.1"
#define PORT 10001

#define MAXL 250
#define TIME 5000
#define NPAD 0
#define PADC 0
#define SOH 0x01
#define EOL 0x0D
#define ZERO 0x00

void create_YS_package(msg * t)
{
	t->payload[0] = SOH;
	t->payload[1] = 5 + 11;
	t->payload[2] = 0x01;
	t->payload[3] = 'Y';
	t->payload[4] = MAXL;
	t->payload[5] = TIME;
	t->payload[6] = NPAD;
	t->payload[7] = PADC;
	t->payload[8] = EOL;
	t->payload[9] = ZERO;
	t->payload[10] = ZERO;	//QBIN
	t->payload[11] = ZERO;	//CHKT
	t->payload[12] = ZERO;	//RPT
	t->payload[13] = ZERO;	// CAPA
	t->payload[14] = ZERO;	//R1
	unsigned short crc = crc16_ccitt(t->payload, 15);
	memcpy(&(t->payload[15]), &crc, 2);
	t->payload[17] = EOL;	// MARK
	t->payload[18] = '\0';
	t->len = strlen(t->payload);
}

// creeaza un pachet Y ca raspuns pt un mesaj S

void create_Y_package(msg * t, char current_SEQ)
{
	t->payload[0] = SOH;
	t->payload[1] = 5;
	t->payload[2] = current_SEQ;
	t->payload[3] = 'Y';
	unsigned short crc = crc16_ccitt(t->payload, 4);
	memcpy(&(t->payload[4]), &crc, 2);
	t->payload[6] = EOL;
	t->payload[7] = '\0';
	t->len = strlen(t->payload);
}

// creeaza un pachet Y cu structura din cerinta

void create_N_package(msg * t, char current_SEQ)
{
	t->payload[0] = SOH;
	t->payload[1] = 5;
	t->payload[2] = current_SEQ;
	t->payload[3] = 'N';
	unsigned short crc = crc16_ccitt(t->payload, 4);
	memcpy(&(t->payload[4]), &crc, 2);
	t->payload[6] = EOL;
	t->payload[7] = '\0';
	t->len = strlen(t->payload);
}

// creeaza un pachet N cu structura din cerinta

int check_crc_is_correct(msg * t)
{
	char computed_string[50];
	char crc_from_structure_string[50];
	unsigned short crc_from_file;
	char aux[2];
	// pe pachete S nu a vrut sa functioneze elseul, asa ca am facut un caz psecial
	if (t->payload[3] == 'S') {
		unsigned short computed_crc = crc16_ccitt(t->payload, 15);
		aux[0] = computed_crc & 0xff;
		aux[1] = (computed_crc >> 8) & 0xff;
		// memcpy ducea la coliziuni cu o probabilitate de 1 octet la 600 000
		// asa ca am folosit trickurile astea pe biti :D
		if (aux[0] == t->payload[15] && aux[1] == t->payload[16]) {
			return 1;
		}
		return 0;
	} else {
		unsigned short computed_crc =
		    crc16_ccitt(t->payload, t->len - 3);
		aux[0] = computed_crc & 0xff;
		aux[1] = (computed_crc >> 8) & 0xff;
		if (aux[0] == t->payload[t->len - 3] &&
		    aux[1] == t->payload[t->len - 2]) {
			return 1;
		}
		return 0;
	}
}

// Verifica daca CRcul este corect

int main(int argc, char **argv)
{
	msg *r, t;
	init(HOST, PORT);
	char SEQ = 1;
	char file_name[500];
	char prefix[] = "recv_";
	char last_mesage_SEQ = -1;
	FILE *file_descriptor;
	int can_send_anymore;
	int intra_de_ori = 0;
	while (1) {
		int intra_de_ori = 0;
		can_send_anymore = 3;
		while (can_send_anymore) {
			r = receive_message_timeout(TIME);
			if (r)
				break;
			else {
				can_send_anymore--;
			}
		}
		// astept de 3 ori sa primesc un mesaj
		// am modificat limita pentru ca pe fisiere mari ar fi crapat
		// (si nu ar fi fost vina mea)
		if (!can_send_anymore)
			return 1;
		// Astept primirea unui mesaj
		if (!check_crc_is_correct(r)) {
			int intra_de_ori = 1;
			create_N_package(&t, SEQ);
			send_message(&t);
			SEQ += 2;
			SEQ %= 64;
			continue;
		} else {
			if (last_mesage_SEQ == r->payload[2]) {
				send_message(&t);
				continue;
			} else {
				create_Y_package(&t, SEQ);
				send_message(&t);
				SEQ += 2;
				SEQ %= 64;
				last_mesage_SEQ = r->payload[2];
			}
		}
		// Verific mai intai daca suma de control e corecta
		// si daca nu e trimit NAK.
		// Daca este duplicat atunci retrimit ultimul mesaj.
		// Altfel trimit mesaj ACK si fac ce zice mesajul sa fac.
		switch (r->payload[3]) {
		case 'S':
			break;
		case 'F':
			strcpy(prefix, "recv_");
			memcpy(file_name, &(r->payload[4]), r->payload[1] - 5);
			file_name[r->payload[1] - 5] = '\0';
			strcat(prefix, file_name);
			file_descriptor = fopen(prefix, "wb");
			break;
		case 'D':
			fwrite(&(r->payload[4]), 1, r->len - 7,
			       file_descriptor);
			// ESTE OK, PENTRU CA SCRIU LUNGIMEA INTREGULUI MESAJ CARE E 
			// 4+buffer_length+3 - 7 = buffer_length
			break;
		case 'Z':
			fclose(file_descriptor);
			break;
		case 'B':
			break;
		}
		if (r->payload[3] == 'B') {
			break;
		}
	}

	return 0;
}
